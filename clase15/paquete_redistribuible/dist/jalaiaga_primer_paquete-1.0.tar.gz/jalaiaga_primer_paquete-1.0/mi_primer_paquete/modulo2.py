#!/usr/bin/env python
# -*- coding: utf-8 -*-

def llamado_modulo2():

    print("soy el modulo2!")
