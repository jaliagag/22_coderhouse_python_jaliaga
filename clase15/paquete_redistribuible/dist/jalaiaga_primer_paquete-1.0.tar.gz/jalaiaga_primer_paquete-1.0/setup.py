#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup

setup(
    name='jalaiaga_primer_paquete',
    version='1.0',
    description='clase 15',
    author='jaliaga',
    authoer_email='jmfaliaga@gmail.com',

    packages=['mi_primer_paquete']

)
